{- Assignment 4
 - Name: TODO add full name
 - Date: TODO add of completion
 -}
module Assign_4 where

macid :: String
macid = "TODO: put your mac id here"


data Poly a = X
            | Coef a
            | Sum (Poly a) (Poly a)
            | Prod (Poly a) (Poly a)
            deriving Show

newtype PolyList a = PolyList [a] deriving Show

{- -----------------------------------------------------------------
 - getPolyList
 - -----------------------------------------------------------------
 - Description: TODO add comments on getPolyList here
 -}
getPolyList :: FilePath -> IO (PolyList Integer)
getPolyList file = error "TODO: implement getPolyList"

{- -----------------------------------------------------------------
 - polyListValue
 - -----------------------------------------------------------------
 - Description: TODO add comments on polyListValue here
 -}
polyListValue :: Num a => PolyList a -> a -> a
polyListValue p1 n = error "TODO: implement polyListValue"

{- -----------------------------------------------------------------
 - polyListDegree
 - -----------------------------------------------------------------
 - Description: TODO add comments on polyListDegree here
 -}
polyListDegree :: Num a => PolyList a -> Integer
polyListDegree p1 = error "TODO: implement polyListDegree"

{- -----------------------------------------------------------------
 - polyListDeriv
 - -----------------------------------------------------------------
 - Description: TODO add comments on polyListDeriv here
 -}
polyListDeriv :: Num a => PolyList a -> PolyList a
polyListDeriv p1 = error "TODO: implement polyListDeriv"

{- -----------------------------------------------------------------
 - polyListSum
 - -----------------------------------------------------------------
 - Description: TODO add comments on polyListSum here
 -}
polyListSum :: Num a => PolyList a -> PolyList a -> PolyList a
polyListSum p1 q1 = error "TODO: implement polyListSum"

{- -----------------------------------------------------------------
 - polyListProd
 - -----------------------------------------------------------------
 - Description: TODO add comments on polyListProd here
 -}
polyListProd :: Num a => PolyList a -> PolyList a -> PolyList a
polyListProd p1 q1 = error "TODO: implement polyListProd"


{- -----------------------------------------------------------------
 - polyListToPoly
 - -----------------------------------------------------------------
 - Description: TODO add comments on polyListToPoly here
 -}
polyListToPoly :: Num a => PolyList a -> Poly a
polyListToPoly p1 = error "TODO: implement polyListToPoly"

{- -----------------------------------------------------------------
 - polyToPolyList
 - -----------------------------------------------------------------
 - Description: TODO add comments on polyToPolyList here
 -}
polyToPolyList :: Num a => PolyList a -> Poly a
polyToPolyList p = error "TODO: implement polyToPolyList"

{- -----------------------------------------------------------------
 - Test Cases
 - -----------------------------------------------------------------
 -
 - -----------------------------------------------------------------
 - - Function:
 - - Test Case Number:
 - - Input:
 - - Expected Output:
 - - Acutal Output:
 - -----------------------------------------------------------------
 - TODO: add test cases
 -}

