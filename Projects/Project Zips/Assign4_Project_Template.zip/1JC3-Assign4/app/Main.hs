module Main where

import qualified Assign_4 as A4
import qualified Assign_4_ExtraCredit as A4E

main :: IO ()
main = putStrLn "Executable for 1JC3-Assign4 successfully run"
