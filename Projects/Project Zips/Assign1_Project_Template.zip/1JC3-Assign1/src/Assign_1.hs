{- Assignment 1
 - Name: TODO add full name
 - Date: TODO add of completion
 -}
module Assign_1 where

macid :: String
macid = "TODO: put your mac id here"

{- -----------------------------------------------------------------
 - cubicQ
 - -----------------------------------------------------------------
 - Description: TODO add comments on cubicQ here 
 -}
cubicQ :: Double -> Double -> Double -> Double
cubicQ a b c = error "TODO: implement cubicQ"

{- -----------------------------------------------------------------
 - cubicR
 - -----------------------------------------------------------------
 - Description: TODO add comments on cubicR here 
 -}
cubicR :: Double -> Double -> Double -> Double -> Double
cubicR a b c d = error "TODO: implement cubicR"

{- -----------------------------------------------------------------
 - cubicDisc
 - -----------------------------------------------------------------
 - Description: TODO add comments on cubicDisc here 
 -}
cubicDisc :: Double -> Double -> Double
cubicDisc q r = error "TODO: implement cubicDisc"

{- -----------------------------------------------------------------
 - cubicS
 - -----------------------------------------------------------------
 - Description: TODO add comments on cubicS here 
 -}
cubicS :: Double -> Double -> Double
cubicS q r = error "TODO: implement cubicS"

{- -----------------------------------------------------------------
 - cubicT
 - -----------------------------------------------------------------
 - Description: TODO add comments on cubicT here 
 -}
cubicT :: Double -> Double -> Double
cubicT q r = error "TODO: implement cubicT"

{- -----------------------------------------------------------------
 - cubicRealSolutions
 - -----------------------------------------------------------------
 - Description: TODO add comments on cubicRealSolutions here 
 -}
cubicRealSolutions :: Double -> Double -> Double -> Double -> [Double]
cubicRealSolutions a b c d = error "TODO: implement cubicRealSolution"

{- -----------------------------------------------------------------
 - Test Cases 
 - -----------------------------------------------------------------
 -}

-- TODO Add Test Cases for each of your functions below here