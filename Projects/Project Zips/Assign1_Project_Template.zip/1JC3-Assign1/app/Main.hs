module Main where

import qualified Assign_1 as A1
import qualified Assign_1_ExtraCredit as A1E

main :: IO ()
main = putStrLn "Executable for 1JC3-Assign1 successfully run"
