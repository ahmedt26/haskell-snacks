{- Assignment 5
 - Name: TODO add full name
 - Date: TODO add of completion
 -}
module Assign_5 where

macid :: String
macid = "TODO: put your mac id here"


{- -----------------------------------------------------------------
 - definiteIntegral
 - -----------------------------------------------------------------
 - Description: TODO add comments on definiteIntegral here
 -}
definiteIntegral :: Double -> Double -> (Double -> Double) -> Integer -> Double
definiteIntegral a b g n = error "TODO: implement definiteIntegral"

{- -----------------------------------------------------------------
 - funH
 - -----------------------------------------------------------------
 - Description: TODO add comments on funH here
 -}
funH :: Integer -> Double
funH n = error "TODO: implement funH"

{- -----------------------------------------------------------------
 - funK
 - -----------------------------------------------------------------
 - Description: TODO add comments on funK here
 -}
funK :: Double -> Double
funK n = error "TODO: implement funK"

{- -----------------------------------------------------------------
 - Test Cases
 - -----------------------------------------------------------------
 -
 - -----------------------------------------------------------------
 - - Function:
 - - Test Case Number:
 - - Input:
 - - Expected Output:
 - - Acutal Output:
 - -----------------------------------------------------------------
 - TODO: add test cases
 -}

