module Main where

import qualified Assign_5 as A5

main :: IO ()
main = putStrLn "Executable for 1JC3-Assign5 successfully run"
