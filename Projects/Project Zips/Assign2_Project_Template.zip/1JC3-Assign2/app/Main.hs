module Main where

import qualified Assign_2 as A2
import qualified Assign_2_ExtraCredit as A2E

main :: IO ()
main = putStrLn "Executable for 1JC3-Assign2 successfully run"
