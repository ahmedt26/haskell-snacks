import Test.QuickCheck
import qualified Assign_2 as A2
import qualified Assign_2_ExtraCredit as A2E

main :: IO ()
main = putStrLn "Test suite not yet implemented"
