{- Assignment 2
 - Name: TODO add full name
 - Date: TODO add of completion
 -}
module Assign_2 where

macid :: String
macid = "TODO: put your mac id here"

type Vector = (Double,Double,Double)

{- -----------------------------------------------------------------
 - vecZero
 - -----------------------------------------------------------------
 - Description: TODO add comments on vecZero here
 -}
vecZero :: Vector
vecZero = error "TODO: implement vecZero"

{- -----------------------------------------------------------------
 - vecScalarProd
 - -----------------------------------------------------------------
 - Description: TODO add comments on vecScalarProd here
 -}
vecScalarProd :: Double -> Vector -> Vector
vecScalarProd x v0 = error "TODO: implement vecScalarProd"

{- -----------------------------------------------------------------
 - vecSum
 - -----------------------------------------------------------------
 - Description: TODO add comments on vecSum here
 -}
vecSum :: Vector -> Vector -> Vector
vecSum v0 v1 = error "TODO: implement vecSum"

{- -----------------------------------------------------------------
 - vecMagnitude
 - -----------------------------------------------------------------
 - Description: TODO add comments on vecMagnitude here
 -}
vecMagnitude :: Vector -> Double
vecMagnitude v0 = error "TODO: implement vecMagnitude"

{- -----------------------------------------------------------------
 - vecInnerProd
 - -----------------------------------------------------------------
 - Description: TODO add comments on vecInnerProd here
 -}
vecInnerProd :: Vector -> Vector -> Double
vecInnerProd v0 v1 = error "TODO: implement vecInnerProd"

{- -----------------------------------------------------------------
 - vecF
 - -----------------------------------------------------------------
 - Description: TODO add comments on vecF here
 -}
vecF :: Vector -> [Vector] -> (Vector,Vector)
vecF v0 vs = error "TODO: implement vecF"

{- -----------------------------------------------------------------
 - Test Cases
 - -----------------------------------------------------------------
 -
 - -----------------------------------------------------------------
 - - Function:
 - - Test Case Number:
 - - Input:
 - - Expected Output:
 - - Acutal Output:
 - -----------------------------------------------------------------
 - TODO: add test cases
 -}

