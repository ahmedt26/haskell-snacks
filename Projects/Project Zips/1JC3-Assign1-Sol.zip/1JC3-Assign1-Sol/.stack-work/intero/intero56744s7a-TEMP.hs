{- Assignment 1
 - Name: Hailan Kan
 - Date: 9/15/2018 ~ 9/25/2018
 -}
module Assign_1 where

macid :: String
macid = "kanh3"

{- -----------------------------------------------------------------
 - cubicQ
 - -----------------------------------------------------------------
 - Description: I: 3 numbers in the type of Double; O: 1 number in
 the type of Double; function: computes Q from a,b,c-}
cubicQ :: Double -> Double -> Double -> Double
cubicQ a b c =  (3 * a * c - b ^ 2) / (9 * a ^ 2)

{- -----------------------------------------------------------------
 - cubicR
 - -----------------------------------------------------------------
 - Description: computes R (Double;O) from a,b,c,d(all of them
 Double; I)-}
cubicR :: Double -> Double -> Double -> Double -> Double
cubicR a b c d = (9 *a *b *c - 27 *a **2 *d - 2 *b ^3) / (54 *a ^3)

{- -----------------------------------------------------------------
 - cubicDisc
 - -----------------------------------------------------------------
 - Description: computes the discriminant(O;Double) from q,r(the
 outputs of the functions cubicQ and cubicR; Double) -}
cubicDisc :: Double -> Double -> Double
cubicDisc q r = q ^ 3  + r ^2

{- -----------------------------------------------------------------
 - cubicRoot
 - -----------------------------------------------------------------
 - Description: a fuction defined by my own, to calculate the cubic
 root (O;Double) of both positive and negative Double numbers(I)-}
cubicRoot :: Double -> Double
cubicRoot x = if x >= 0
  then x ** (1/3)
  else abs x ** (1/3) * (-1)

{- -----------------------------------------------------------------
 - cubicS
 - -----------------------------------------------------------------
 - Description: computes S (Double;O) from q,r(both Double;I); uses
 function cubicRoot-}
cubicS :: Double -> Double -> Double
cubicS q r = cubicRoot (r + sqrt(q ** 3 + r **2))

{- -----------------------------------------------------------------
 - cubicT
 - -----------------------------------------------------------------
 - Description: computes T (Double;O) from q,r(both Double;I); uses
 function cubicRoot-}
cubicT :: Double -> Double -> Double
cubicT q r = cubicRoot (r - sqrt(q ** 3 + r** 2))

{- -----------------------------------------------------------------
 - cubicRealSolutions
 - -----------------------------------------------------------------
 - Description: gives only the real solution(s) in the form of a
 list for the equation, given a,b,c,d, coefficients of the equation
 uses functions cubicQ,cubicR,cubicDisc,cubicS,and cubicT-}
cubicRealSolutions :: Double -> Double -> Double -> Double -> [Double]
cubicRealSolutions a b c d
    | abs (cubicDisc q r) < 1e-6  = [x1,x2,x2]
    | cubicDisc q r > 1e-6        = [x1]
    | otherwise                   = []
    where
      x1 = cubicS q r
         + cubicT q r
         - b / (3*a)
      x2 = (-1) * (cubicS q r + cubicT q r)/2
         - b/(3*a)
     -- + i * sqrt(3) (cubicS (cubicQ a b c) (cubicR a b c d) - cubicT (cubicQ a b c) (cubicR a b c d))/2
     -- when cubicDisc = 0 , cubicS = cubicT, so line 77 equals 0
      q = cubicQ a b c
      r = cubicR a b c d
{- -----------------------------------------------------------------
 - Test Cases
 - -----------------------------------------------------------------
 -}


-- Function  Case#  Detail        Result                Expected   Pass/Fail
--cubicQ    1    a=3,b=-2,c=1   6.172839506172839e-2     5/81         P
--          2     5,8,7         0.18222222222222223      41/225       P
--          3     10,-10,1      -7.777777777777778e-2    -7/90        P
--cubicR    1   a=1,b=3,c=5,d=2    0.5                    0.5         P
--          2   -3,8,4,4          1.9615912208504802    2860/1458     P
--          3    6,-2,9,11        -0.9986282578875172  -11648/11664   P
--cubicDisc 1    q=1,r=-1/2        1.25                    1.25       P
--          2     1,-3             10.0                    10         P
--          3     -7,11           -222.0                 -222         P
--cubicRoot 1      27              3.0                   3            P
--          2      0                0.0                   0           P
--          3    -125              -4.999999999999        5           P
--cubicS    1     1,-1/2        0.851799642079243  0.851799642079243  P
--          2     1,-3         0.5454474457696384  0.5454474458       P
--          3     -7,11            NaN                  NaN           P
--cubicT    1     1,-1/2    -1.1739849967053284  -1.1739849967053284  P
--          2     1,-3       -1.8333571964737654  -1.833357196        P
--          3     -7,11            NaN                  NaN           P
--cubicRealSolutions
--          1    1,-6,11,-6        []                   []            F
--          2    1,-3,3,-1      [1.0,1.0,1.0]       [1,1,1]           P
--          3    1,-1,1,1  [-0.5436890126920766][-0.5436890126920766] P
