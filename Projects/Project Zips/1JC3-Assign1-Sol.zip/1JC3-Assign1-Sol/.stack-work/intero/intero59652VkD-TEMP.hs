module Main where

import System.IO
import Data.Bits
import Data.List
import Test.QuickCheck (quickCheckResult,quickCheckWithResult,stdArgs,maxSuccess,Result(Success))

import qualified Assign_1 as Student

{- ----------------------------------------------------------------------------------------------------------------
 - Assignment 1 Sample Solution (Verified by quickcheck cubicRealProp)
 - ----------------------------------------------------------------------------------------------------------------
 -}
(***) :: Double -> Double -> Double
x *** y = if x >= 0 then x ** y else -( (-x) ** y)

(===) :: Double -> Double -> Bool
x === y = let
  tol = 1e-3
  in abs (x-y) <= tol

cubicQ :: Double -> Double -> Double -> Double
cubicQ a b c = let
        x1 = 3 * a * c - b^2
        x2 = 9 * a^2
    in x1 / x2

cubicR :: Double -> Double -> Double -> Double -> Double
cubicR a b c d = let
        x1 = 9 * a * b * c
        x2 = 27 * d * a^2
        x3 = 2 * b^3
        x4 = 54 * a^3
    in (x1 - x2 - x3)  / x4

cubicS :: Double -> Double -> Double
cubicS q r = (r + (q**3 + r**2)**(1/2)) *** (1/3)

cubicT :: Double -> Double -> Double
cubicT q r = (r - (q**3 + r**2)**(1/2)) *** (1/3)

cubicDisc :: Double -> Double -> Double
cubicDisc q r = q**3 + r**2

cubicRealSolutions :: Double -> Double -> Double -> Double -> [Double]
cubicRealSolutions a b c d
  | disc === 0  = filter (not . isNaN) [x1,x2,x3] -- NOTE: custom floating pt equality
  | disc < 0    = []
  | disc > 0    = filter (not . isNaN) [x1]
  | isNaN disc  = []
  where
    disc = cubicDisc q r
    x1   = st - ba
    x2   = -st - ba
    x3   = x2
    st   = s + t
    ba   = b / (3*a)
    s    = cubicS q r
    t    = cubicT q r
    q    = cubicQ a b c
    r    = cubicR a b c d

{- ----------------------------------------------------------------------------------------------------------------
 -  QuickCheck Properties
 - ----------------------------------------------------------------------------------------------------------------
 -}

{- Test cubicRealSolution
 - ----------------------------------------------------------------------------------------------------------------
 -    Polynomial roots should always be within a reasonable (albeit larger than should be acceptable) tolerance
 -    from 0 when evaluated
 -      Note: Straightforward implementation's of this method are susceptible to very large floating point
 -            error for "tricky" polynomials, and quickCheck is smart and will usually find them
 -            cubicRealProp constrains quickCheck to "easy" polynomials by limiting to integer coefficients
 -            between (-25,25)
 -}
cubicRealProp :: (Int,Int,Int,Int) -> Bool
cubicRealProp (a',b',c',d') = let
      (a,b,c,d) = (fromIntegral $ (a' `mod` 50) - 25
                  ,fromIntegral $ (b' `mod` 50) - 25
                  ,fromIntegral $ (c' `mod` 50) - 25
                  ,fromIntegral $ (d' `mod` 50) - 25)
      tol  = 8e-1
      disc = cubicDisc (cubicQ a b c) (cubicR a b c d)
      xs   = Student.cubicRealSolutions a b c d
  in if isNaN disc
        then True
        else case filter (not . isNaN) xs of
               (x0:_) -> abs (hornerEval (a,b,c,d) x0) <= tol
               []     -> disc < 0 || length xs > 0

{- Helper Function
 - ----------------------------------------------------------------------------------------------------------------
 - Evaluate given polynomial (a,b,c,d) at x0 using horner's method
 - https://en.wikipedia.org/wiki/Horner%27s_method
 -}
--hornerEval :: (Double,Double,Double,Double) -> Double -> Double
hornerEval (a,b,c,d) x0 = d + x0 * (c + x0 * (b + x0 * a))


{- Test cubicS,cubicT,cubicQ,cubicR
 - ----------------------------------------------------------------------------------------------------------------
 -    If cubicRealProp fails, part marks can be gained if cubicS,cubicT,cubicQ,cubicR compare reasonably
 -    to my own implementation, under proper conditions
 -}
cubicQProp :: (Double,Double,Double) -> Bool
cubicQProp (a,b,c) = let
    tol   = 8e-1
    r0    = Student.cubicQ a b c
    r1    = cubicQ a b c
    cond  = abs a >= 1.0 && r1 > tol
  in (not cond) || (abs (r1-r0) <= tol)

cubicRProp :: (Double,Double,Double,Double) -> Bool
cubicRProp (a,b,c,d) = let
    tol   = 8e-1
    r0    = Student.cubicR a b c d
    r1    = cubicR a b c d
    cond  = abs a > 1.0 && r1 > tol
  in (not cond) || (abs (r1-r0) <= tol)

cubicSProp :: (Double,Double) -> Bool
cubicSProp (q,r) = let
    tol   = 8e-1
    s0    = Student.cubicS q r
    s0'   = Student.cubicS r q
    s1    = cubicS q r
    cond  = q^3 + r^2 > tol && s1 > tol
  in (not cond) || (abs (s1-s0) <= tol) || (abs (s1-s0') <= tol)

cubicTProp :: (Double,Double) -> Bool
cubicTProp (q,r) = let
    tol   = 8e-1
    t0    = Student.cubicT q r
    t0'   = Student.cubicT r q
    t1    = cubicT q r
    cond  = q^3 + r^2 > tol &&  t1 > tol
  in (not cond) || (abs (t1-t0) <= tol) || (abs (t1-t0') <= tol)

{- ----------------------------------------------------------------------------------------------------------------
 -  Run test against Assign_1 module in current directory and output results as a list
 - ----------------------------------------------------------------------------------------------------------------
 -}
main = do {
    result_real <- quickCheckResult cubicRealProp;
    result_q    <- quickCheckResult cubicQProp;
    result_r    <- quickCheckResult cubicRProp;
    result_s    <- quickCheckResult cubicSProp;
    result_t    <- quickCheckResult cubicTProp;
    putStrLn $ show [result_real,result_s,result_t,result_q,result_r] }
