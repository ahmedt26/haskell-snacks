{- Assignment 1
 - Name: Omar Alkersh
 - Date: 22/09/2018
 -}
module Assign_1 where
import           Data.Complex

macid :: String
macid = "alkersho"



(***) :: Double -> Double -> Double
x *** y = if x >= 0 then x ** y else -( (-x) ** y)

(===) :: Double -> Double -> Bool
x === y = let
  tol = 1e-6
  in abs (x-y) <= tol

cubicQ :: Double -> Double -> Double -> Double
cubicQ a b c = let
        x1 = 3 * a * c - b^2
        x2 = 9 * a^2
    in x1 / x2

cubicR :: Double -> Double -> Double -> Double -> Double
cubicR a b c d = let
        x1 = 9 * a * b * c
        x2 = 27 * d * a^2
        x3 = 2 * b^3
        x4 = 54 * a^3
    in (x1 - x2 - x3)  / x4

cubicS :: Double -> Double -> Double
cubicS q r = (r + (q**3 + r**2)**(1/2)) *** (1/3)

cubicT :: Double -> Double -> Double
cubicT q r = (r - (q**3 + r**2)**(1/2)) *** (1/3)

cubicDisc :: Double -> Double -> Double
cubicDisc q r = q**3 + r**2

cubicRealSolutions :: Double -> Double -> Double -> Double -> [Double]
cubicRealSolutions a b c d
  | disc === 0 = [x1,x2,x3] -- NOTE: custom floating pt equality
  | disc < 0   = []
  | disc > 0   = [x1]
  where
    disc = cubicDisc q r
    x1   = st - ba
    x2   = -st - ba
    x3   = x2
    st   = s + t
    ba   = b / (3*a)
    s    = cubicS q r
    t    = cubicT q r
    q    = cubicQ a b c
    r    = cubicR a b c d





