module Main where

import System.IO
import Data.Bits
import Data.List
import Test.QuickCheck (quickCheckResult,quickCheckWithResult,stdArgs,maxSuccess,Result(Success))

import qualified Assign_1 as Student

{- ----------------------------------------------------------------------------------------------------------------
 - Assignment 1 Sample Solution (Verified by quickcheck cubicRealProp)
 - ----------------------------------------------------------------------------------------------------------------
 -}
(***) :: Double -> Double -> Double
x *** y = if x >= 0 then x ** y else -( (-x) ** y)

(===) :: Double -> Double -> Bool
x === y = let
  tol = 1e-6
  in abs (x-y) <= tol

cubicQ :: Double -> Double -> Double -> Double
cubicQ a b c = let
        x1 = 3 * a * c - b^2
        x2 = 9 * a^2
    in x1 / x2

cubicR :: Double -> Double -> Double -> Double -> Double
cubicR a b c d = let
        x1 = 9 * a * b * c
        x2 = 27 * d * a^2
        x3 = 2 * b^3
        x4 = 54 * a^3
    in (x1 - x2 - x3)  / x4

cubicS :: Double -> Double -> Double
cubicS q r = (r + (q**3 + r**2)**(1/2)) *** (1/3)

cubicT :: Double -> Double -> Double
cubicT q r = (r - (q**3 + r**2)**(1/2)) *** (1/3)

cubicDisc :: Double -> Double -> Double
cubicDisc q r = q**3 + r**2

cubicRealSolutions :: Double -> Double -> Double -> Double -> [Double]
cubicRealSolutions a b c d
  | disc === 0 = [x1,x2,x3] -- NOTE: custom floating pt equality
  | disc < 0   = []
  | disc > 0   = [x1]
  where
    disc = cubicDisc q r
    x1   = st - ba
    x2   = -st - ba
    x3   = x2
    st   = s + t
    ba   = b / (3*a)
    s    = cubicS q r
    t    = cubicT q r
    q    = cubicQ a b c
    r    = cubicR a b c d

{- ----------------------------------------------------------------------------------------------------------------
 -  QuickCheck Properties
 - ----------------------------------------------------------------------------------------------------------------
 -}

{- Test cubicRealSolution
 - ----------------------------------------------------------------------------------------------------------------
 -    Polynomial roots should always be within a reasonable (albeit larger than should be acceptable) tolerance
 -    from 0 when evaluated
 -      Note: Straightforward implementation's of this method are susceptible to very large floating point
 -            error for "tricky" polynomials, and quickCheck is smart and will usually find them
 -            cubicRealProp constrains quickCheck to "easy" polynomials by limiting to integer coefficients
 -            between (-25,25)
 -}
cubicRealProp :: (Int,Int,Int,Int) -> Bool
cubicRealProp (a',b',c',d') = let
      (a,b,c,d) = (fromIntegral $ (a' `mod` 50) - 25
                  ,fromIntegral $ (b' `mod` 50) - 25
                  ,fromIntegral $ (c' `mod` 50) - 25
                  ,fromIntegral $ (d' `mod` 50) - 25)
      tol  = 8e-1
      disc = cubicDisc (cubicQ a b c) (cubicR a b c d)
      xs   = Student.cubicRealSolutions a b c d
  in case xs of
       (x0:_) -> (disc >= -tol) && (abs (hornerEval (a,b,c,d) x0) <= tol)
       []     -> disc < 0

{- Helper Function
 - ----------------------------------------------------------------------------------------------------------------
 - Evaluate given polynomial (a,b,c,d) at x0 using horner's method
 - https://en.wikipedia.org/wiki/Horner%27s_method
 -}
--hornerEval :: (Double,Double,Double,Double) -> Double -> Double
hornerEval (a,b,c,d) x0 = d + x0 * (c + x0 * (b + x0 * a))


{- Test cubicS,cubicT,cubicQ,cubicR
 - ----------------------------------------------------------------------------------------------------------------
 -    If cubicRealProp fails, part marks can be gained if cubicS,cubicT,cubicQ,cubicR compare reasonably
 -    to my own implementation, under proper conditions
 -}

cubicQProp :: (Double,Double,Double) -> Bool
cubicQProp (a,b,c) = let
    tol   = 8e-1
    r0    = Student.cubicQ a b c
    r1    = cubicQ a b c
    cond  = abs a >= 1.0 && r1 > tol
  in (not cond) || (abs (r1-r0) <= tol)

cubicRProp :: (Double,Double,Double,Double) -> Bool
cubicRProp (a,b,c,d) = let
    tol   = 8e-1
    r0    = Student.cubicR a b c d
    r1    = cubicR a b c d
    cond  = abs a > 1.0 && r1 > tol
  in (not cond) || (abs (r1-r0) <= tol)

cubicSProp :: (Double,Double) -> Bool
cubicSProp (q,r) = let
    tol   = 8e-1
    s0    = Student.cubicS q r
    s0'   = Student.cubicS r q
    s1    = cubicS q r
    cond  = q^3 + r^2 > tol && s1 > tol
  in (not cond) || (abs (s1-s0) <= tol) || (abs (s1-s0') <= tol)

cubicTProp :: (Double,Double) -> Bool
cubicTProp (q,r) = let
    tol   = 8e-1
    t0    = Student.cubicT q r
    t0'   = Student.cubicT r q
    t1    = cubicT q r
    cond  = q^3 + r^2 > tol &&  t1 > tol
  in (not cond) || (abs (t1-t0) <= tol) || (abs (t1-t0') <= tol)

{- ----------------------------------------------------------------------------------------------------------------
 -  Run test against Assign_1 module in current directory and output results to Assign1_Marks.csv
 - ----------------------------------------------------------------------------------------------------------------
 -}
resultsToCSV :: [Result] -> String
resultsToCSV results = let
    mark_scheme = [4,2,2,1,1]
    res2Int res = case res of
                    Success _ _ _ -> 1
                    _             -> 0
    marks       = zipWith (*) mark_scheme $ map res2Int results
    --marks'      = marks ++ [sum marks] -- include sum total
    csv_line    = (lookupStudentNum Student.macid) : (map show marks)
  in  "#" ++ (intercalate "," csv_line) ++ ",#\n"

main = do {
    result_real <- quickCheckWithResult (stdArgs { maxSuccess = 100 }) cubicRealProp;
    result_q    <- quickCheckResult cubicQProp;
    result_r    <- quickCheckResult cubicRProp;
    result_s    <- quickCheckResult cubicSProp;
    result_t    <- quickCheckResult cubicTProp;
    appendFile "Assign1_Marks.csv" $ resultsToCSV [result_real,result_s,result_t,result_q,result_r] }
    -- appendFile (Student.root_path ++ "/Assign1_Marks.csv")
    --   ("((" ++ Student.student_num ++ ")," ++ show (result_real,result_s,result_t,result_q,result_r)) }

lookupStudentNum mac_id = case lookup mac_id classList of
                            Just stud_num -> stud_num
                            Nothing -> error $ "failed to lookup stud num for: " ++ mac_id
isStudNum stud_num = stud_num `elem` (map snd classList)
classList = [("abadip1",	"400176648"),
              ("ahmadcf",	"001225848"),
              ("ahmedt26",	"400185441"),
              ("ahujas6",	"400207645"),
              ("alkersho",	"400214491"),
              ("ayubh",	        "400193027"),
              ("baciudad",	"400084090"),
              ("bhatts39",	"400190373"),
              ("bhavsd1",	"400186161"),
              ("chens187",	"400171303"),
              ("chiz4",	        "400176376"),
              ("cuib6",	        "400198535"),
              ("daiy29",	"400188179"),
              ("dizona",	"400195766"),
              ("fanj37",	"400178530"),
              ("fant8",	        "400189710"),
              ("gabah",	        "400214494"),
              ("gbenjoo",	"400169909"),
              ("gohars1",	"400131114"),
              ("gunaratu",	"400189501"),
              ("guox54",	"400212997"),
              ("haoc3",	        "400195268"),
              ("ipeaiyeo",	"400182152"),
              ("kanh3",	        "400207974"),
              ("kapooa13",	"400168056"),
              ("kaya6",	        "400204607"),
              ("kianis4",	"400189668"),
              ("kims171",	"400183197"),
              ("kostiukb",	"400179192"),
              ("kumars35",	"400220225"),
              ("laffonp",	"400223858"),
              ("leej229",	"400182530"),
              ("lij416",	"400204743"),
              ("linj121",	"400208075"),
              ("liuy363",	"400172720"),
              ("liy443",	"400197570"),
              ("makk4",	        "001318946"),
              ("mikhaily",	"400186838"),
              ("milanovn",	"400171310"),
              ("mortensc",	"400215847"),
              ("muw2",	        "400146269"),
              ("nafeesa",	"400209755"),
              ("ningh4",	"400183343"),
              ("onireto",	"001427487"),
              ("parisc",	"400223865"),
              ("patea80",	"400185305"),
              ("puy4",	        "400116860"),
              ("rizkally",	"400189946"),
              ("robern3",	"400211348"),
              ("sainim4",	"001041622"),
              ("shahrr3",	"001429241"),
              ("sunwooj",	"400181945"),
              ("tariqm16",	"400180258"),
              ("trinhc2",	"400192333"),
              ("wangw107",	"400179829"),
              ("wangx308",	"400188521"),
              ("xiny13",	"400178526"),
              ("yousufma",	"001411376"),
              ("zaidia10",	"400211637"),
              ("zhanz214",	"400207866"),
              ("zhouz110",	"400189359"),
              ("zhua15",	"400169901"),
              ("zhuanh9",	"400192712") ]
